package clase12.src;

public interface GravadorImpuesto {
    double gravar(double porcentaje);
}
