package clase11;

public class ImpresoraEpson extends Impresora{

    @Override
    public String imprimir(){
        return "Imprimiendo tu orden de impresora con tu Epson";
    }
}
